<?php

return [
    'name' => 'Subdomain',
    'module_version' => '1.0',
    'host' => '127.0.0.1',
    'port' => '3306',
    'database' => 'b_panone',
    'username' => 'babaerp_user',
    'password' => 'Babaerp@123',

    //Subscription amount
    'subscription_amount' => 12000
];

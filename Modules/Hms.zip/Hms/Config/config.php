<?php

return [
    'name' => 'Hms',
    'module_version' => '1.0',
    'pid' => '18',
];
